import random
import pygame
import json
import cv2
from google.colab import output
from google.colab.patches import cv2_imshow

def rnd():
    return random.randint(1, 10)

def getImages(cell_size):
    bear_image = pygame.image.load('./images/bear.png')
    bear_image = pygame.transform.scale(bear_image, (cell_size, cell_size))
    dear_image = pygame.image.load('./images/deer.png')
    dear_image = pygame.transform.scale(dear_image, (cell_size, cell_size))
    giraffe_image = pygame.image.load('./images/giraffe.png')
    giraffe_image = pygame.transform.scale(giraffe_image, (cell_size, cell_size))
    hot_image = pygame.image.load('./images/hot.png')
    hot_image = pygame.transform.scale(hot_image, (cell_size, cell_size))
    lettuce_image = pygame.image.load('./images/lettuce.png')
    lettuce_image = pygame.transform.scale(lettuce_image, (cell_size, cell_size))
    lion_image = pygame.image.load('./images/lion.png')
    lion_image = pygame.transform.scale(lion_image, (cell_size, cell_size))
    tiger_image = pygame.image.load('./images/tiger.png')
    tiger_image = pygame.transform.scale(tiger_image, (cell_size, cell_size))
    return bear_image, dear_image, giraffe_image, hot_image, lettuce_image, lion_image, tiger_image

class DynamicEntity:
    def __init__(self, row, column, image, cell_size):
        self.row, self.column = row, column
        self.image = image
        self.cell_size = cell_size

    def move(self, direction):
        if direction == "left":
            dx, dy = (-1, 0)
        elif direction == "right":
            dx, dy = (1, 0)
        elif direction == "up":
            dx, dy = (0, -1)
        elif direction == "down":
            dx, dy = (0, 1)
        new_row = max(0, min(self.row + dy, 4))
        new_column = max(0, min(self.column + dx, 4))
        self.row, self.column = new_row, new_column

    def draw(self, surface):
        rect_x = self.column * self.cell_size
        rect_y = self.row * self.cell_size
        surface.blit(self.image, (rect_x, rect_y))


class FixEntity:
    def __init__(self, row, column, image, cell_size):
        self.row, self.column = row, column
        self.image = image
        self.cell_size = cell_size

    def draw(self, surface):
        rect_x = self.column * self.cell_size
        rect_y = self.row * self.cell_size
        surface.blit(self.image, (rect_x, rect_y))

def create_board():
    pygame.init()

    screen_width, screen_height = 600, 600
    cell_size = screen_width // 5
    screen = pygame.display.set_mode((screen_width, screen_height))
    clock = pygame.time.Clock()

    return screen, clock, cell_size

def test1():
    with open("./CPTs.json", "r") as f:
        cpts = json.load(f)
    screen, clock, cell_size = create_board()

    bear_image, dear_image, giraffe_image, hot_image, lettuce_image, lion_image, tiger_image = getImages(cell_size)

    bear_x = 3
    bear_y = 4
    dear_x = 0
    dear_y = 1

    bear = DynamicEntity(bear_x, bear_y, bear_image, cell_size)
    dear = FixEntity(dear_x, dear_y, dear_image, cell_size)

    cell_graphs = [
        [cpts[f"down{rnd()}"], cpts[f"up{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"right{rnd()}"], cpts[f"right{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"right{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"]]
    ]
    directions = [
        ["down", "up", "left", "left", "left"],
        ["right", "right", "up", "up", "left"],
        ["right", "up", "up", "up", "left"],
        ["up", "up", "up", "up", "left"],
        ["up", "up", "up", "up", "up"]
    ]

    fix_elements = [dear]

    counter = 0
    while counter != 2:
        rand_x = random.randint(0, 4)
        rand_y = random.randint(0, 4)

        if (rand_x != bear_x or rand_y != bear_y) and (rand_x != dear_x or rand_y != dear_y):
            observed_dict = cell_graphs[rand_x][rand_y]["observed"]
            first_key = list(observed_dict.keys())[0]
            if first_key == "1":
                obj = FixEntity(rand_x, rand_y, hot_image, cell_size)
            elif first_key == "2":
                obj = FixEntity(rand_x, rand_y, giraffe_image, cell_size)
            elif first_key == "3":
                if random.randint(0, 1) == 0:
                    obj = FixEntity(rand_x, rand_y, lion_image, cell_size)
                else:
                    obj = FixEntity(rand_x, rand_y, tiger_image, cell_size)
            elif first_key == "4":
                obj = FixEntity(rand_x, rand_y, lettuce_image, cell_size)
            fix_elements.append(obj)
            counter += 1

    return screen, clock, cell_graphs, directions, bear, fix_elements, 6

def test2():
    with open("./CPTs.json", "r") as f:
        cpts = json.load(f)
    screen, clock, cell_size = create_board()

    bear_image, dear_image, giraffe_image, hot_image, lettuce_image, lion_image, tiger_image = getImages(cell_size)

    bear_x = 0
    bear_y = 4
    dear_x = 4
    dear_y = 2

    bear = DynamicEntity(bear_x, bear_y, bear_image, cell_size)
    dear = FixEntity(dear_x, dear_y, dear_image, cell_size)

    cell_graphs = [
        [cpts[f"down{rnd()}"], cpts[f"down{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"down{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"down{rnd()}"], cpts[f"down{rnd()}"], cpts[f"left{rnd()}"], cpts[f"up{rnd()}"], cpts[f"up{rnd()}"]],
        [cpts[f"right{rnd()}"], cpts[f"right{rnd()}"], cpts[f"right{rnd()}"], cpts[f"down{rnd()}"], cpts[f"left{rnd()}"]],
        [cpts[f"up{rnd()}"], cpts[f"up{rnd()}"], cpts[f"down{rnd()}"], cpts[f"left{rnd()}"], cpts[f"up{rnd()}"]]
    ]
    directions = [
        ["down", "down", "left", "left", "left"],
        ["down", "left", "left", "left", "left"],
        ["down", "down", "left", "up", "up"],
        ["right", "right", "right", "down", "left"],
        ["up", "up", "down", "left", "up"]
    ]

    fix_elements = [dear]

    counter = 0
    while counter != 2:
        rand_x = random.randint(0, 4)
        rand_y = random.randint(0, 4)

        if (rand_x != bear_x or rand_y != bear_y) and (rand_x != dear_x or rand_y != dear_y):
            observed_dict = cell_graphs[rand_x][rand_y]["observed"]
            first_key = list(observed_dict.keys())[0]
            if first_key == "1":
                obj = FixEntity(rand_x, rand_y, hot_image, cell_size)
            elif first_key == "2":
                obj = FixEntity(rand_x, rand_y, giraffe_image, cell_size)
            elif first_key == "3":
                if random.randint(0, 1) == 0:
                    obj = FixEntity(rand_x, rand_y, lion_image, cell_size)
                else:
                    obj = FixEntity(rand_x, rand_y, tiger_image, cell_size)
            elif first_key == "4":
                obj = FixEntity(rand_x, rand_y, lettuce_image, cell_size)
            fix_elements.append(obj)
            counter += 1

    return screen, clock, cell_graphs, directions, bear, fix_elements, 12

def test3():
    with open("./CPTs.json", "r") as f:
        cpts = json.load(f)
    screen, clock, cell_size = create_board()

    bear_image, dear_image, giraffe_image, hot_image, lettuce_image, lion_image, tiger_image = getImages(cell_size)

    bear_x = 2
    bear_y = 0
    dear_x = 2
    dear_y = 2

    bear = DynamicEntity(bear_x, bear_y, bear_image, cell_size)
    dear = FixEntity(dear_x, dear_y, dear_image, cell_size)

    cell_graphs = [
        [cpts[f"down9"], cpts[f"left1"], cpts[f"left3"], cpts[f"left4"], cpts[f"left6"]],
        [cpts[f"down9"], cpts[f"up1"], cpts[f"up2"], cpts[f"left8"], cpts[f"down3"]],
        [cpts[f"left11"], cpts[f"left11"], cpts[f"left11"], cpts[f"left11"], cpts[f"left10"]],
        [cpts[f"right1"], cpts[f"right2"], cpts[f"up6"], cpts[f"left1"], cpts[f"left3"]],
        [cpts[f"left11"], cpts[f"up8"], cpts[f"up7"], cpts[f"up9"], cpts[f"left4"]]
    ]
    directions = [
        ["down", "left", "left", "left", "left"],
        ["down", "up", "up", "left", "down"],
        ["right", "right", "up", "up", "left"],
        ["right", "right", "up", "left", "left"],
        ["right", "up", "up", "up", "left"]
    ]

    fix_elements = [dear]

    counter = 0
    while counter != 2:
        rand_x = random.randint(0, 4)
        rand_y = random.randint(0, 4)

        if (rand_x != bear_x or rand_y != bear_y) and (rand_x != dear_x or rand_y != dear_y):
            observed_dict = cell_graphs[rand_x][rand_y]["observed"]
            first_key = list(observed_dict.keys())[0]
            if first_key == "1":
                obj = FixEntity(rand_x, rand_y, hot_image, cell_size)
            elif first_key == "2":
                obj = FixEntity(rand_x, rand_y, giraffe_image, cell_size)
            elif first_key == "3":
                if random.randint(0, 1) == 0:
                    obj = FixEntity(rand_x, rand_y, lion_image, cell_size)
                else:
                    obj = FixEntity(rand_x, rand_y, tiger_image, cell_size)
            elif first_key == "4":
                obj = FixEntity(rand_x, rand_y, lettuce_image, cell_size)
            fix_elements.append(obj)
            counter += 1

    return screen, clock, cell_graphs, directions, bear, fix_elements, 2

def test4():
    with open("./CPTs.json", "r") as f:
        cpts = json.load(f)
    screen, clock, cell_size = create_board()

    bear_image, dear_image, giraffe_image, hot_image, lettuce_image, lion_image, tiger_image = getImages(cell_size)

    bear_x = 4
    bear_y = 4
    dear_x = 1
    dear_y = 2

    bear = DynamicEntity(bear_x, bear_y, bear_image, cell_size)
    dear = FixEntity(dear_x, dear_y, dear_image, cell_size)

    cell_graphs = [
        [cpts[f"down1"], cpts[f"down2"], cpts[f"right3"], cpts[f"right9"], cpts[f"down10"]],
        [cpts[f"down3"], cpts[f"down4"], cpts[f"down9"], cpts[f"right8"], cpts[f"down1"]],
        [cpts[f"down5"], cpts[f"down6"], cpts[f"up8"], cpts[f"left2"], cpts[f"left9"]],
        [cpts[f"down7"], cpts[f"down8"], cpts[f"right5"], cpts[f"right7"], cpts[f"up9"]],
        [cpts[f"right1"], cpts[f"right2"], cpts[f"right4"], cpts[f"right6"], cpts[f"up10"]]
    ]
    directions = [
        ["down", "down", "right", "right", "down"],
        ["down", "down", "down", "right", "down"],
        ["down", "down", "up", "left", "left"],
        ["down", "down", "right", "right", "up"],
        ["right", "right", "right", "right", "up"]
    ]

    fix_elements = [dear]

    counter = 0
    while counter != 2:
        rand_x = random.randint(0, 4)
        rand_y = random.randint(0, 4)

        if (rand_x != bear_x or rand_y != bear_y) and (rand_x != dear_x or rand_y != dear_y):
            observed_dict = cell_graphs[rand_x][rand_y]["observed"]
            first_key = list(observed_dict.keys())[0]
            if first_key == "1":
                obj = FixEntity(rand_x, rand_y, hot_image, cell_size)
            elif first_key == "2":
                obj = FixEntity(rand_x, rand_y, giraffe_image, cell_size)
            elif first_key == "3":
                if random.randint(0, 1) == 0:
                    obj = FixEntity(rand_x, rand_y, lion_image, cell_size)
                else:
                    obj = FixEntity(rand_x, rand_y, tiger_image, cell_size)
            elif first_key == "4":
                obj = FixEntity(rand_x, rand_y, lettuce_image, cell_size)
            fix_elements.append(obj)
            counter += 1

    return screen, clock, cell_graphs, directions, bear, fix_elements, 5

def play_game(show_direction_def, test_def):
    screen, clock, cell_graphs, directions, bear, fix_elements, number_of_moves = test_def()

    counter_of_moves = 0

    while True:
        screen.fill((255, 255, 255))

        for element in fix_elements:
            element.draw(screen)

        predicted_direction = show_direction_def(cell_graphs[bear.row][bear.column])
        if predicted_direction == directions[bear.row][bear.column]:
            counter_of_moves += 1
        else:
            counter_of_moves += 2
        bear.move(predicted_direction)
        bear.draw(screen)

        if bear.row == fix_elements[0].row and bear.column == fix_elements[0].column:
            break

        pygame.display.update()
        clock.tick(1)

        view = pygame.surfarray.array3d(screen)
        view = view.transpose([1, 0, 2])
        img_bgr = cv2.cvtColor(view, cv2.COLOR_RGB2BGR)
        output.clear(wait=True)
        cv2_imshow(img_bgr)

    pygame.quit()
    if counter_of_moves == number_of_moves:
        print("Test PASSED!")
    else:
        print("Test FAILED!")